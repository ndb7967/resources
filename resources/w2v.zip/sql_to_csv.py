from itertools import permutations
import pickle

with open('./data/word2idx.pickle', 'rb') as f:
    word2idx = pickle.load(f)
with open('./data/idx2word.pickle', 'rb') as f:
    idx2word = pickle.load(f)
with open('./data/cluster_data.pickle', 'rb') as f:
    cluster_data = pickle.load(f)
print(cluster_data[:5])

train_data = []
for t in cluster_data:
    for c in permutations(t, 2):
        train_data.append(c)

with open('./data/train_data.pickle', 'rb') as f:
    train_data = pickle.load(f)
print(train_data[:5])

with open('./data/x.pickle', 'rb') as f:
    x = pickle.load(f)
with open('./data/y.pickle', 'rb') as f:
    y = pickle.load(f)

print(x[:5])
print(y[:5])

import tensorflow as tf
import numpy as np

x = np.asarray(x)
y = np.asarray(y)

tag_count = x.shape[1]

print(x.shape, y.shape)

autoencoder_input = tf.keras.layers.Input(shape=(tag_count,))
autoencoder_in = tf.keras.layers.Dense(units=tag_count)(autoencoder_input)
autoencoder_compress = tf.keras.layers.Dense(units=10)(autoencoder_in)
autoencoder_out = tf.keras.layers.Dense(units=tag_count)(autoencoder_compress)

autoencoder = tf.keras.Model(inputs=autoencoder_input, outputs=autoencoder_out)

autoencoder.compile(loss=tf.keras.losses.CategoricalCrossentropy(), optimizer=tf.keras.optimizers.Adam(learning_rate=0.00001), metrics=['accuracy'])
autoencoder.fit(x, y, epochs=10, batch_size=32)

autoencoder.save('./model/word2vec')

